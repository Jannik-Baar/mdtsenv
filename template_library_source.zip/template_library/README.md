<h2>Template Library</h2>
Die Template Library ist eine Vorlage mit der neue Libraries erstellt werden können, dies wird in den nachfolgenden 7 Schritten erklärt:

 **1. Extrahieren:** Die template_library_source.zip Datei extrahieren. (Dies ist höchstwahrscheinlich schon geschehen, wenn dieses README gelesen wird)
 
**2. Verschieben/Kopieren:** Der im ersten Schritt extrahierte *template_library* Ordner muss in das pgmtss-main Hauptverzeichnis verschoben werden, sollte er dort noch nicht liegen.
 
**3. Umbenennen:** Dem verschobenen *template_library* Ordner einen gewünschten neuen Library-Namen geben und in diesen umbenennen. **WICHTIG: Der neue Name muss das Wort "_library" enthalten, damit die Library von dem JAXBIndexBuilder erkannt wird. (z.B. "traffic_library")**
 
**4. Modulname:** In der pom.xml in *template_library/* jedes Vorkommen des Wortes "template_library" mit dem neuen Namen aus Schritt 3 ersetzen.

**5. Dependency (optional)**: Wenn die neue Library nicht nur auf der base_library aufbauen soll, sondern auf einer Library, die die base_library intern schon benutzt (z.B. die maritime_library), muss in der in Schritt 4 angepassten pom.xml zusätzlich jedes Vorkommen des Wortes "base_library" mit dem anderen Library Namen ersetzt werden (Ersetze z.B. "base_library" mit "maritime_library"). Vorraussetzung ist natürlich, dass Maven irgendwie Zugriff auf die neue Library hat, sollte die zu verwendende Library nicht im pgmtss-main Hauptverzeichnis liegen.
 
**6. Einbinden:** Die neue Library muss in dem Maven Project als Module eingebunden werden. Dafür muss in der pom.xml im pgtss-main Hauptverzeichnis die neue Zeile *\<module>NEUERLIBRARYNAME\</module>*, unter *\<modules>* hinzugefügt werden. NEUERLIBRARYNAME meint hierbei den in Schritt 3 erstellten Librarynamen.

**7. Load Changes:** Die Änderungen am Maven Projekt können nun geladen werden (in IntelliJ z.B. mit "Load Maven Changes" oder "Reload All Maven Projects"), die neue Library sollte anschließend korrekt eingebunden sein und die Entwicklung kann beginnen.

Nach Ausführen dieser 7 Schritte sollte die Struktur im Hauptverzeichnis wie folgt aussehen:

    pgmtss-main
        |
        base_library
        maritime_library
        simulation
        pom.xml
        ...
        NEUELIBRARY_library
                |
                src
                    |
                    main
                        |
                        java
                            |
                            library
                                |
                                datamodel
                                    |
                                    ...
                                services
                                    |
                                    ...
                        resources
                            |
                            ...
                    test
                        |
                        ...
                pom.xml
                README.md

Für eine detaillierte Erklärung wie eine Library aufgebaut ist, siehe die README.md in *base_library* oder *maritime_library*, oder die Dokumentation. 